// chat.js
const socket = io();

// Handle the send button click
document.getElementById('send-btn').addEventListener('click', () => {
    const message = document.getElementById('chat-input').value;
    const roomName = document.getElementById('room-name').value;
    if (message && roomName) {
        socket.emit('chatMessage', message, roomName);
        document.getElementById('chat-input').value = '';  // Clear input
    }
});

// Handle joining a room when the user enters the room name
document.getElementById('room-name').addEventListener('input', () => {
    const roomName = document.getElementById('room-name').value;
    if (roomName) {
        socket.emit('joinRoom', roomName);
    }
});

// Listen for incoming messages
socket.on('chatMessage', (message) => {
    const chatBox = document.getElementById('chat-box');
    const messageElement = document.createElement('div');
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);
});
