// server.js
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

// Initialize Express
const app = express();
const server = http.createServer(app);
const io = socketIo(server);  // Initialize Socket.io

// Serve static files (if you want to serve front-end from same server)
app.use(express.static('public'));

// Handle WebSocket connections
io.on('connection', (socket) => {
  console.log('New user connected');

  // Handle joining a room
  socket.on('joinRoom', (roomName) => {
    socket.join(roomName);
    console.log(`User joined room: ${roomName}`);
  });

  // Handle sending a message
  socket.on('chatMessage', (message, roomName) => {
    io.to(roomName).emit('chatMessage', message);
  });

  // Handle disconnect
  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

// Start the server
server.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
